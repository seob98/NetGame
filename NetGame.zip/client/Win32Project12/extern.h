#pragma once

extern HWND	hWnd;