#include "stdafx.h"
#include "Block.h"



void CBlock::draw(HDC hdc)
{
}
